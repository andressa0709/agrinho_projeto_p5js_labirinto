let player;  
let walls = [];
let started = false;
let questions = [
  { question: "Qual é a melhor época para plantar alface?", answer: "outono" },
  { question: "Qual nutriente é essencial para crescimento?", answer: "nitrogenio" },
  { question: "Quantas horas de sol por dia a maioria das hortaliças precisa?", answer: "6" }
];
let currentQuestion = 0;
let showingQuestion = false;
let input;
let showEnd = false;

function setup() {
  createCanvas(600, 400);
  player = createVector(50, 50);
  input = createInput();
  input.position(-1000, -1000); // Esconde inicialmente
  input.input(checkAnswer);
  setupWalls();
}

function draw() {
  background(220);

  if (!started) {
    textAlign(CENTER, CENTER);
    textSize(24);
    text("Pressione ESPAÇO para começar", width / 2, height / 2);
    return;
  }

  if (showEnd) {
    textAlign(CENTER, CENTER);
    textSize(26);
    text("Você chegou ao mercado! Parabéns!", width / 2, height / 2);
    return;
  }

  // Desenha labirinto
  for (let wall of walls) {
    wall.show();
  }

  fill(0, 200, 0);
  ellipse(player.x, player.y, 20, 20); // jogador

  fill(200, 100, 0);
  rect(550, 350, 40, 40); // mercado (ponto final)

  if (!showingQuestion) {
    movePlayer();
    checkCollisions();
    checkGoal();
    checkQuestionZones();
  }

  if (showingQuestion) {
    textSize(16);
    fill(0);
    textAlign(LEFT, TOP);
    text(questions[currentQuestion].question, 20, 20);
  }
}

function keyPressed() {
  if (key === ' ') {
    started = true;
  }
}

function movePlayer() {
  if (keyIsDown(LEFT_ARROW)) player.x -= 2;
  if (keyIsDown(RIGHT_ARROW)) player.x += 2;
  if (keyIsDown(UP_ARROW)) player.y -= 2;
  if (keyIsDown(DOWN_ARROW)) player.y += 2;
}

function setupWalls() {
  walls.push(new Wall(100, 0, 20, 300));
  walls.push(new Wall(200, 100, 300, 20));
  walls.push(new Wall(400, 200, 20, 150));
  // adicione mais paredes conforme desejar
}

function checkCollisions() {
  for (let wall of walls) {
    if (wall.hits(player)) {
      // Reset para o início se bater
      player.set(50, 50);
    }
  }
}

function checkGoal() {
  if (player.x > 550 && player.y > 350) {
    showEnd = true;
  }
}

function checkQuestionZones() {
  if (currentQuestion < questions.length) {
    if (dist(player.x, player.y, 150 + currentQuestion * 100, 200) < 20) {
      showingQuestion = true;
      input.position(20, 50);
    }
  }
}

function checkAnswer() {
  let ans = input.value().toLowerCase().trim();
  if (ans === questions[currentQuestion].answer) {
    input.value('');
    input.position(-1000, -1000);
    currentQuestion++;
    showingQuestion = false;
  }
}

class Wall {
  constructor(x, y, w, h) {
    this.x = x; this.y = y;
    this.w = w; this.h = h;
  }

  show() {
    fill(100);
    rect(this.x, this.y, this.w, this.h);
  }

  hits(p) {
    return (p.x > this.x && p.x < this.x + this.w &&
            p.y > this.y && p.y < this.y + this.h);
  }
}
